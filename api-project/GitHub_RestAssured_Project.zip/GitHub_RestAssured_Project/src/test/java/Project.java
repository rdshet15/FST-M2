import static io.restassured.RestAssured.given;
import static org.hamcrest.CoreMatchers.equalTo;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import io.restassured.builder.RequestSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class Project {
	   // Declare request specification
    RequestSpecification requestSpec;
    String sshKey ;
    int sshKeyId;
    
       @BeforeClass
    public void setUp() {
        // Create request specification
        requestSpec = new RequestSpecBuilder()
                // Set content type
                .setContentType(ContentType.JSON)
                //add token
                .addHeader("Authorization","token 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")
                // Set base URL
                .setBaseUri("https://api.github.com")
                // Build request specification
                .build();   
                }
       
       @Test(priority =1 )
       public void addSshKey() {
    	   
    	   sshKey  = "ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQC6PSyNHSR9khfaKvOiI2bv003xkABkJebdFGSKykhpF44qBOw2iS4t3PPs4Cr/wPwMWCnxAHdMqjsuuHgha3uQzv05II0Iv+cexNCHOoMUqc19ZK6aGk/kjEoCcH8VlwEA4LUwhzZzuXaVscJxxlinA4ULR+xuluaz6LpFZvEO1xIRMe/m+ico5roCXmgcvTzpFDbe/iGoTFMuwS+R0ZzOSmX+oLsfajHk3mixiiilgstzWZ9bD8KBaLDKEn67YeJI5Q8+6vvD7UdX2A1yB8Kp94pWlYiNLcTDceINMoGaCMb7uQLPl7//Dhz/j7t7xqwU2aH6Uiir3slOGFL5RZHt";
    	   String reqBody = "{\"title\":\"TestAPIKey1\", \"key\": \"" +sshKey +"\" }";
    	
    	   Response response = given()
    			   .spec(requestSpec) // Use requestSpec
                   .body(reqBody) // Send request body
                   .when().post("/user/keys"); // Send POST request
    	
    	   
    	   String responseBody = response.getBody().asPrettyString();
    	   System.out.println(responseBody);
    	   System.out.println(response.getStatusCode());
    	   sshKeyId= response.then().extract().path("id");
    	// Assertion
           response.then().statusCode(201);
       }
       @Test(priority = 2)
       public void getSsshKey() {
    	   Response response = given()
    			   .spec(requestSpec)
    			   .when().get("/user/keys"); //send get request
    	   String resposeBody = response.getBody().asPrettyString();
    	   System.out.println(resposeBody);
    	   System.out.println(response.getStatusCode());
    	   
    	   //Assertion
    	   response.then().statusCode(200);
       }
    	   
    	@Test(priority = 3)
    	private void delectKey() {
			Response response = given()
					.spec(requestSpec)
					.when().pathParam("keyId", sshKeyId).delete("/user/keys/{keyId}");
			
			System.out.println(response.getBody().asPrettyString());
			
			//Assertion
			response.then().statusCode(204);
					

		}
    	
   
       
}
